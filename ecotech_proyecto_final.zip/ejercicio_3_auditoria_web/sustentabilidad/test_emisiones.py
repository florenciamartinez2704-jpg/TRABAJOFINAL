import unittest

from django.test import SimpleTestCase

from .emisiones import calcular_emisiones_carbono
from .metricas import obtener_metricas_consumo


class TestCalculoEmisiones(unittest.TestCase):
    def test_consumo_nominal_factor_por_defecto(self):
        self.assertAlmostEqual(calcular_emisiones_carbono(100), 40.0)

    def test_factor_personalizado(self):
        self.assertAlmostEqual(calcular_emisiones_carbono(200, 0.5), 100.0)

    def test_consumo_cero(self):
        self.assertEqual(calcular_emisiones_carbono(0), 0)

    def test_consumo_negativo_lanza_error(self):
        with self.assertRaises(ValueError):
            calcular_emisiones_carbono(-10)


class TestMetricas(unittest.TestCase):
    def test_total_y_planta_mayor(self):
        registros = [
            {"planta": "A", "consumo_kwh": 100},
            {"planta": "B", "consumo_kwh": 300},
            {"planta": "A", "consumo_kwh": 50},
        ]
        r = obtener_metricas_consumo(registros)
        self.assertAlmostEqual(r["total_emisiones"], 180.0)
        self.assertEqual(r["planta_mayor_consumo"], "B")


class TestVistaPanel(SimpleTestCase):
    def test_panel_responde_con_contexto(self):
        respuesta = self.client.get("/panel/")
        self.assertEqual(respuesta.status_code, 200)
        self.assertIn("total_emisiones", respuesta.context)
        self.assertEqual(respuesta.context["planta_mayor_consumo"], "Planta Sur")
