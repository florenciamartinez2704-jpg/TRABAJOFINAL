from .emisiones import calcular_emisiones_carbono


def obtener_metricas_consumo(registros):
    """registros: lista de dicts con 'planta' y 'consumo_kwh' (puede haber varios por planta)."""
    consumo_por_planta = {}
    total_emisiones = 0

    for reg in registros:
        planta = reg["planta"]
        consumo = reg["consumo_kwh"]
        total_emisiones += calcular_emisiones_carbono(consumo)
        consumo_por_planta[planta] = consumo_por_planta.get(planta, 0) + consumo

    if consumo_por_planta:
        planta_mayor = max(consumo_por_planta, key=consumo_por_planta.get)
    else:
        planta_mayor = None

    return {
        "total_emisiones": total_emisiones,
        "planta_mayor_consumo": planta_mayor,
        "consumo_por_planta": consumo_por_planta,
    }
