import json
from pathlib import Path

from django.shortcuts import render

from .metricas import obtener_metricas_consumo

ARCHIVO_DATOS = Path(__file__).resolve().parent / "data" / "consumos.json"


def vista_panel_sustentabilidad(request):
    with open(ARCHIVO_DATOS, encoding="utf-8") as f:
        registros = json.load(f)

    metricas = obtener_metricas_consumo(registros)

    contexto = {
        "titulo": "Panel de Sustentabilidad",
        "total_emisiones": round(metricas["total_emisiones"], 2),
        "planta_mayor_consumo": metricas["planta_mayor_consumo"],
        "consumo_por_planta": metricas["consumo_por_planta"],
    }
    return render(request, "sustentabilidad/panel.html", contexto)
