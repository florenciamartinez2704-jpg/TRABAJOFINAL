import json


class GestorInventario:
    def guardar_catalogo_json(self, lista_dispositivos, ruta_archivo):
        catalogo = [d.a_diccionario() for d in lista_dispositivos]
        with open(ruta_archivo, "w", encoding="utf-8") as archivo:
            json.dump(catalogo, archivo, indent=4, ensure_ascii=False)
