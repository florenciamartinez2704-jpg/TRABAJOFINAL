class StockInvalidoError(Exception):
    """Se lanza cuando se intenta poner un stock negativo."""
    pass


class DispositivoEcológico:
    def __init__(self, nombre, precio, stock):
        self.nombre = nombre
        self.precio = precio
        self.stock = stock  # pasa por el setter, así también se valida al crear

    @property
    def stock(self):
        return self.__stock

    @stock.setter
    def stock(self, valor):
        if valor < 0:
            raise StockInvalidoError(f"Stock inválido ({valor}): no puede ser negativo")
        self.__stock = valor

    def ficha_tecnica(self):
        return f"{self.nombre} | Precio: ${self.precio} | Stock: {self.stock} unidades"

    def a_diccionario(self):
        return {
            "tipo": self.__class__.__name__,
            "nombre": self.nombre,
            "precio": self.precio,
            "stock": self.stock,
        }


class PanelSolar(DispositivoEcológico):
    def __init__(self, nombre, precio, stock, potencia_w, eficiencia):
        super().__init__(nombre, precio, stock)
        self.potencia_w = potencia_w
        self.eficiencia = eficiencia  # en porcentaje

    # polimorfismo: misma función, ficha distinta
    def ficha_tecnica(self):
        base = super().ficha_tecnica()
        return f"[Panel Solar] {base} | Potencia: {self.potencia_w}W | Eficiencia: {self.eficiencia}%"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["potencia_w"] = self.potencia_w
        datos["eficiencia"] = self.eficiencia
        return datos
