from modelos import DispositivoEcológico, PanelSolar, StockInvalidoError
from gestor import GestorInventario

productos = []

# productos válidos
productos.append(DispositivoEcológico("Cargador solar portátil", 15000, 40))
productos.append(PanelSolar("Panel Monocristalino 450W", 320000, 12, 450, 21.5))
productos.append(PanelSolar("Panel Policristalino 280W", 180000, 25, 280, 17.0))

# intento con stock erróneo, tiene que saltar la excepción
try:
    panel_malo = PanelSolar("Panel defectuoso", 100000, -5, 300, 18.0)
    productos.append(panel_malo)
except StockInvalidoError as e:
    print("Error capturado al crear:", e)

# también al modificar un producto que ya existe
try:
    productos[1].stock = -1
except StockInvalidoError as e:
    print("Error capturado al asignar:", e)

print()
for p in productos:
    print(p.ficha_tecnica())

GestorInventario().guardar_catalogo_json(productos, "catalogo_ecotech.json")
print("\nCatálogo guardado en catalogo_ecotech.json")
