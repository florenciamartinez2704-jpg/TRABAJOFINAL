# Proyecto Final - EcoTech Solutions

Requisitos: Python 3.10+ y Django (solo para el ejercicio 3).

## Ejercicio 1
    cd ejercicio_1_sensores
    python sensores.py

## Ejercicio 2
    cd ejercicio_2_productos
    python main.py        # genera catalogo_ecotech.json

## Ejercicio 3
    cd ejercicio_3_auditoria_web
    pip install -r requirements.txt
    python manage.py test         # corre los tests
    python manage.py runserver    # abrir http://127.0.0.1:8000/panel/
