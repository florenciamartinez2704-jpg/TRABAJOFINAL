UBICACION_DEFECTO = "Sin ubicacion"


def limpiar_registro_sensor(registro_raw):
    """Recibe un dict crudo de un sensor y devuelve uno limpio."""
    # id sin espacios sobrantes
    sensor_id = str(registro_raw.get("sensor_id", "")).strip()

    # temperatura: saco la unidad y la paso a float
    temp_texto = str(registro_raw.get("temperatura", "")).strip().upper()
    temp_texto = temp_texto.replace("°", "").replace("C", "").strip()
    try:
        temperatura = float(temp_texto)
    except ValueError:
        temperatura = None  # lectura inválida o faltante

    # ubicacion: si no viene o está vacía uso el valor por defecto
    ubicacion = str(registro_raw.get("ubicacion", "")).strip()
    if not ubicacion:
        ubicacion = UBICACION_DEFECTO

    return {
        "sensor_id": sensor_id,
        "temperatura": temperatura,
        "ubicacion": ubicacion,
    }


def generar_resumen_sensores(lista_sensores_limpios, umbral_temperatura):
    """Devuelve (ids de sensores que superan el umbral, promedio de temperatura)."""
    sensores_alerta = []
    temperaturas = []

    for sensor in lista_sensores_limpios:
        temp = sensor["temperatura"]
        if temp is None:
            continue  # no cuenta para el promedio ni para las alertas
        temperaturas.append(temp)
        if temp > umbral_temperatura:
            sensores_alerta.append(sensor["sensor_id"])

    if temperaturas:
        promedio = sum(temperaturas) / len(temperaturas)
    else:
        promedio = 0.0

    return sensores_alerta, promedio


if __name__ == "__main__":
    registros_crudos = [
        {"sensor_id": " SENSOR-001 ", "temperatura": "24.5C", "ubicacion": "Planta Norte"},
        {"sensor_id": "SENSOR-002", "temperatura": " 31.2 C", "ubicacion": "Planta Sur"},
        {"sensor_id": "  SENSOR-003", "temperatura": "28°C"},
        {"sensor_id": "SENSOR-004 ", "temperatura": "35.8C", "ubicacion": "  "},
        {"sensor_id": "SENSOR-005", "temperatura": "error", "ubicacion": "Planta Este"},
    ]
    umbral = 30.0

    limpios = [limpiar_registro_sensor(r) for r in registros_crudos]
    alerta, promedio = generar_resumen_sensores(limpios, umbral)

    print("=== REPORTE DE SENSORES - EcoTech Solutions ===")
    for s in limpios:
        print(f"{s['sensor_id']:<12} {str(s['temperatura']):>6}  {s['ubicacion']}")
    print("-" * 40)
    print(f"Umbral de temperatura: {umbral} C")
    print(f"Sensores en alerta: {', '.join(alerta) if alerta else 'ninguno'}")
    print(f"Promedio global: {promedio:.2f} C")
